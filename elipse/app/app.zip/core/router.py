from typing import Optional

CODE_KEYWORDS = [
    "código", "codigo", "función", "funcion", "bug", "error",
    "script", "python", "javascript", "clase", "debug",
    "variable", "compilar", "sintaxis", "api", "endpoint",
    "sql", "html", "css", "algoritmo"
]

HISTORY_LOOKBACK = 4  # cuántos mensajes previos revisar para sostener el rol "código" en un seguimiento


def _find_code_keyword(text: str) -> Optional[str]:
    lowered = (text or "").lower()
    for keyword in CODE_KEYWORDS:
        if keyword in lowered:
            return keyword
    return None


def choose_provider(message: str, history: Optional[list] = None):
    """
    Devuelve (model_name, reason) según reglas simples.
    Primero mira el mensaje actual; si ahí no hay pistas, mira los últimos
    mensajes de la conversación — así un "¿y en C?" después de pedir código
    en Python sigue yendo al proveedor de código, en vez de caer al general
    solo porque esa frase suelta no repite ninguna palabra clave.
    """
    keyword = _find_code_keyword(message)
    if keyword:
        return "code", f"palabra clave de código detectada: '{keyword}'"

    for prev in reversed((history or [])[-HISTORY_LOOKBACK:]):
        keyword = _find_code_keyword(prev.get("content", ""))
        if keyword:
            return "code", f"sigue una conversación de código (se detectó '{keyword}' antes)"

    return "general", "sin palabras clave de código, usando modelo general"