"""Fish Audio (nube). POST https://api.fish.audio/v1/tts → audio por pedazos (HTTP streaming)."""

from typing import Iterator

import httpx

from app.config import settings
from app.core.voice.providers.base import VoiceError, VoiceProvider

FISH_URL = "https://api.fish.audio/v1/tts"


class FishProvider(VoiceProvider):
    name = "fish"
    is_cloud = True
    mime = "audio/mpeg"

    def available(self) -> bool:
        return bool(settings.voice_fish_api_key)

    def stream(self, text: str, voice_id: str = "") -> Iterator[bytes]:
        headers = {
            "Authorization": f"Bearer {settings.voice_fish_api_key}",
            "Content-Type": "application/json",
            "model": settings.voice_fish_model,          # el header "model" es obligatorio en Fish
        }
        body = {"text": text, "format": "mp3", "latency": "balanced"}
        if voice_id:
            body["reference_id"] = voice_id
        timeout = httpx.Timeout(connect=10, read=settings.voice_timeout_seconds, write=10, pool=10)
        try:
            with httpx.stream("POST", FISH_URL, headers=headers, json=body, timeout=timeout) as r:
                if r.status_code != 200:
                    r.read()
                    raise VoiceError(f"Fish respondió {r.status_code}: {r.text[:200]}")
                got = False
                for chunk in r.iter_bytes(4096):
                    if chunk:
                        got = True
                        yield chunk
                if not got:
                    raise VoiceError("Fish devolvió audio vacío.")
        except httpx.HTTPError as e:
            raise VoiceError(f"Fish: {type(e).__name__}: {e}") from e
